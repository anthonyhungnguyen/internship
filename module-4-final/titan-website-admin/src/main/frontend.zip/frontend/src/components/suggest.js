export const rolesListSuggest = [
    'Administrator',
    'Executive',
    'Customer service',
]

export const rolesListSearchSuggest = [
    'All',
    'Administrator',
    'Executive',
    'Customer service',
]

export const typeSearchSuggest = [
    'All',
    '[0] INTERNAL',
    '[1] REQUEST',
    '[2] HTTP',
    '[3] GRPC',
    '[4] REDIS',
    '[5] MYSQL',
    '[6] MONGODB'
]