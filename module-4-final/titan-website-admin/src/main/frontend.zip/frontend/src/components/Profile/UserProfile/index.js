import React from 'react'
import { Tabs } from 'antd'

const { TabPane } = Tabs

export default () => {
	return <p>Hello</p>
}
