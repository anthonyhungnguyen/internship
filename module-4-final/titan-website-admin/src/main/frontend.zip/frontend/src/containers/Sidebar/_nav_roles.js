export default {
  items_roles: [
    {
      name: 'Filter',
      roles: ['ADMIN'],

    },
    {
      name: 'D3',
      roles: ['ADMIN', 'USER'],
    },
    {
      name: 'FixTable',
      roles: ['ADMIN', 'USER', 'CS'],
    },
    {
      name: 'ADMIN',
      roles: ['ADMIN'],
    },
    {
      name: 'RoleManagement',
      roles: ['ADMIN'],
    },
    {
      name: 'NavManagement',
      roles: ['ADMIN'],
    },
    {
      name: 'Profile',
      roles: ["ADMIN"]
    }
  ],
};
