import EventOptions from './EventOptions';

export default {
    EventOptions
};