// domain
// 	id
// 	name

// profile
// 	id
// 	name
// 	filter
// 	conditions

// tier 
// 	id
// 	name
// 	priority
// 	decision
// 	filter
// 	conditions
// rule
// 	id
// 	infoCode
// 	filter
// 	sourceType
// 	sourceName - type - url - method - timeout
// 	maintenance start 
// 	maintenance end
// 	timeInterval
// 	conditions